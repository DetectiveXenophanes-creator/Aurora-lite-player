package com.aurora.lite

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.Player
import coil.compose.AsyncImage

private data class Detail(val title: String, val songs: List<Song>, val playlistId: Long? = null, val smart: String? = null)

/** What the ⋮ menu of a song can do. [remove] is only set inside a playlist. */
private class SongActions(
    val playNext: (Song) -> Unit,
    val addToQueue: (Song) -> Unit,
    val addToPlaylist: (Song) -> Unit,
    val remove: ((Song) -> Unit)?,
    val toggleFavorite: (Song) -> Unit,
)

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

private fun songsText(n: Int) = if (n == 1) "1 song" else "$n songs"

private fun greeting(): String = when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..21 -> "Good evening"
    else -> "Good night"
}

@Composable
fun LiteApp(vm: PlayerViewModel, colorInt: Int, onColor: (Int) -> Unit) {
    val context = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, audioPermission()) == android.content.pm.PackageManager.PERMISSION_GRANTED)
    }
    val request = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[audioPermission()] == true) {
            granted = true
            vm.loadSongs(force = true)
        }
    }

    // Know when the app is on screen (fewer wake-ups in the background) and refresh the music list when it returns
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, granted) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) {
                vm.uiVisible = true
                if (granted) vm.loadSongs()
            } else if (event == Lifecycle.Event.ON_STOP) {
                vm.uiVisible = false
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (!granted) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(32.dp), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Icon(Icons.Rounded.MusicNote, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onBackground)
                Text("Aurora Lite", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground)
                Text(
                    "Allow access to your music so Aurora Lite can play it.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = {
                    val perms = if (Build.VERSION.SDK_INT >= 33) {
                        arrayOf(audioPermission(), Manifest.permission.POST_NOTIFICATIONS)
                    } else arrayOf(audioPermission())
                    request.launch(perms)
                }) { Text("Allow") }
            }
        }
        return
    }
    LaunchedEffect(Unit) { vm.loadSongs() }
    LiteMain(vm, colorInt, onColor)
}

@Composable
private fun LiteMain(vm: PlayerViewModel, colorInt: Int, onColor: (Int) -> Unit) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val songs by vm.songs.collectAsState()
    val ui by vm.ui.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val lib by vm.library.collectAsState()
    var tab by rememberSaveable { mutableStateOf(0) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var showColor by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf(setOf<Long>()) }
    var selectMenu by remember { mutableStateOf(false) }
    var addTargets by remember { mutableStateOf<List<Song>?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var createFor by remember { mutableStateOf<List<Song>>(emptyList()) }
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    val byId = remember(songs) { songs.associateBy { it.id } }
    val detailPlaylist = detail?.playlistId?.let { id -> playlists.firstOrNull { it.id == id } }
    val q = query.trim()
    val shown = remember(songs, q) {
        if (q.isEmpty()) songs else songs.filter {
            it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
        }
    }
    val d = detail
    val detailSongs: List<Song> = when {
        d == null -> emptyList()
        d.playlistId != null -> detailPlaylist?.songIds?.mapNotNull { byId[it] } ?: emptyList()
        d.smart == "fav" -> songs.filter { it.id in lib.favorites }
        d.smart == "top" -> songs.filter { (lib.plays[it.id] ?: 0) > 0 }.sortedByDescending { lib.plays[it.id] ?: 0 }.take(50)
        d.smart == "recent" -> lib.recent.mapNotNull { byId[it] }
        else -> d.songs
    }
    // The song list that is on screen right now (the one multi-select works on)
    val visibleSongs = when {
        d != null -> detailSongs
        tab == 1 -> shown
        else -> emptyList()
    }
    val selecting = selectedIds.isNotEmpty()
    val selectedSongs = if (selecting) visibleSongs.filter { it.id in selectedIds } else emptyList()

    LaunchedEffect(tab, detail) { selectedIds = emptySet() }

    fun toast(msg: String, long: Boolean = false) =
        Toast.makeText(context, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
    fun toggle(song: Song) {
        selectedIds = if (song.id in selectedIds) selectedIds - song.id else selectedIds + song.id
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = runCatching {
                val text = vm.createBackup(colorInt)
                context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) } ?: error("no stream")
            }.isSuccess
            toast(if (ok) "Backup saved" else "Could not save the backup")
        }
    }
    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching { context.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } }.getOrNull()
            if (text == null) {
                toast("Could not read that file")
            } else {
                val result = vm.restoreBackup(text)
                result.color?.let { onColor(it) }
                toast(result.message, long = true)
            }
        }
    }

    // The one registered last is checked first: player, then selection, then leaving a detail page
    BackHandler(enabled = !showPlayer && detail != null) { detail = null }
    BackHandler(enabled = selecting) { selectedIds = emptySet() }
    BackHandler(enabled = showPlayer) { showPlayer = false }

    val actions = SongActions(
        playNext = { vm.playNext(listOf(it)); toast("Plays next") },
        addToQueue = { vm.addToQueue(listOf(it)); toast("Added to queue") },
        addToPlaylist = { addTargets = listOf(it) },
        remove = detailPlaylist?.let { pl -> { song: Song -> vm.removeFromPlaylist(pl.id, song.id) } },
        toggleFavorite = { vm.toggleFavorite(it.id) },
    )

    Box(Modifier.fillMaxSize().background(cs.background)) {
        Column(Modifier.fillMaxSize()) {
            if (selecting) {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(start = 8.dp, end = 4.dp, top = 8.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { selectedIds = emptySet() }) { Icon(Icons.Rounded.Close, "Cancel selection") }
                    Text(
                        "${selectedIds.size} selected",
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.weight(1f).padding(start = 4.dp),
                    )
                    IconButton(onClick = { selectedIds = visibleSongs.map { it.id }.toSet() }) { Icon(Icons.Rounded.SelectAll, "Select all") }
                    IconButton(onClick = { vm.play(selectedSongs, 0); selectedIds = emptySet() }) { Icon(Icons.Rounded.PlayArrow, "Play") }
                    Box {
                        IconButton(onClick = { selectMenu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                        DropdownMenu(expanded = selectMenu, onDismissRequest = { selectMenu = false }) {
                            DropdownMenuItem(text = { Text("Play next") }, onClick = {
                                selectMenu = false
                                vm.playNext(selectedSongs)
                                toast("${songsText(selectedSongs.size)} play next")
                                selectedIds = emptySet()
                            })
                            DropdownMenuItem(text = { Text("Add to queue") }, onClick = {
                                selectMenu = false
                                vm.addToQueue(selectedSongs)
                                toast("${songsText(selectedSongs.size)} added to queue")
                                selectedIds = emptySet()
                            })
                            DropdownMenuItem(text = { Text("Add to playlist") }, onClick = {
                                selectMenu = false
                                addTargets = selectedSongs
                            })
                            DropdownMenuItem(text = { Text("Add to favourites") }, onClick = {
                                selectMenu = false
                                vm.addFavorites(selectedSongs.map { it.id })
                                toast("${songsText(selectedSongs.size)} added to favourites")
                                selectedIds = emptySet()
                            })
                            if (detailPlaylist != null) {
                                DropdownMenuItem(text = { Text("Remove from this playlist") }, onClick = {
                                    selectMenu = false
                                    vm.removeSongsFromPlaylist(detailPlaylist.id, selectedIds)
                                    selectedIds = emptySet()
                                })
                            }
                        }
                    }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (detail != null) {
                        IconButton(onClick = { detail = null }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
                    }
                    Text(
                        detailPlaylist?.name ?: detail?.title ?: "Aurora Lite",
                        style = MaterialTheme.typography.headlineSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    if (detailPlaylist != null) {
                        IconButton(onClick = { renaming = true }) { Icon(Icons.Rounded.Edit, "Rename playlist") }
                        IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, "Delete playlist") }
                    } else {
                        IconButton(onClick = { showColor = true }) { Icon(Icons.Rounded.Settings, "Settings") }
                    }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    d != null -> SongList(
                        detailSongs, ui.current?.id, selectedIds, lib.favorites, showShuffle = true, actions = actions,
                        emptyText = if (d.playlistId != null) "This playlist is empty.\nUse the ⋮ menu on any song to add it." else "No songs found",
                        onShuffle = { vm.playShuffled(detailSongs) },
                        onTap = { i, s -> if (selecting) toggle(s) else vm.play(detailSongs, i) },
                        onToggle = { toggle(it) },
                    )
                    tab == 0 -> HomeTab(
                        songs, lib, ui.current?.id, actions, byId,
                        onPlayAll = { vm.play(songs, 0) },
                        onShuffle = { vm.playShuffled(songs) },
                        onOpen = { detail = it },
                        onPlay = { list, i -> vm.play(list, i) },
                    )
                    tab == 1 -> Column(Modifier.fillMaxSize()) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            placeholder = { Text("Search songs") },
                            leadingIcon = { Icon(Icons.Rounded.Search, null) },
                            shape = RoundedCornerShape(28.dp),
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                        )
                        SongList(
                            shown, ui.current?.id, selectedIds, lib.favorites, showShuffle = q.isEmpty(), actions = actions,
                            emptyText = "No songs found",
                            onShuffle = { vm.playShuffled(shown) },
                            onTap = { i, s -> if (selecting) toggle(s) else vm.play(shown, i) },
                            onToggle = { toggle(it) },
                        )
                    }
                    tab == 2 -> {
                        val albums = remember(songs) {
                            songs.groupBy { it.albumId }.values.sortedBy { it.first().album.lowercase() }
                        }
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(albums, key = { it.first().albumId }) { list ->
                                val first = list.first()
                                val artist = if (list.map { it.artist }.distinct().size > 1) "Various artists" else first.artist
                                BrowseRow(first, first.album, "$artist · ${songsText(list.size)}") {
                                    detail = Detail(first.album, list)
                                }
                            }
                        }
                    }
                    tab == 3 -> {
                        val artists = remember(songs) {
                            songs.groupBy { it.artist }.entries.sortedBy { it.key.lowercase() }
                        }
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(artists, key = { it.key }) { e ->
                                BrowseRow(e.value.first(), e.key, songsText(e.value.size)) {
                                    detail = Detail(e.key, e.value)
                                }
                            }
                        }
                    }
                    else -> LazyColumn(Modifier.fillMaxSize()) {
                        item {
                            TextButton(
                                onClick = { createFor = emptyList(); showCreate = true },
                                modifier = Modifier.padding(horizontal = 8.dp),
                            ) {
                                Icon(Icons.Rounded.Add, null, Modifier.size(20.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("New playlist")
                            }
                        }
                        if (playlists.isEmpty()) {
                            item {
                                Text(
                                    "No playlists yet. Create one, then add songs with the ⋮ menu on any song.",
                                    color = cs.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                                )
                            }
                        }
                        items(playlists, key = { it.id }) { pl ->
                            val count = pl.songIds.count { it in byId }
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .clickable { detail = Detail(pl.name, emptyList(), pl.id) }
                                    .padding(start = 10.dp, top = 8.dp, bottom = 8.dp, end = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(cs.surfaceVariant),
                                    contentAlignment = Alignment.Center,
                                ) { Icon(Icons.Rounded.QueueMusic, null, tint = cs.onSurfaceVariant) }
                                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                                    Text(pl.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                                    Text(songsText(count), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            Dock(vm, ui, tab, onTab = { tab = it; detail = null }, onOpenPlayer = { showPlayer = true }, onOpenQueue = { showQueue = true })
        }

        // No slide animation: the player simply appears
        if (showPlayer && ui.current != null) {
            NowPlaying(vm, ui, favorite = (ui.current?.id ?: -1L) in lib.favorites, onClose = { showPlayer = false }, onQueue = { showQueue = true })
        }
    }

    if (showColor) {
        SettingsSheet(
            colorInt, onColor,
            onBackup = { saveLauncher.launch("aurora-lite-backup.json") },
            onRestore = { openLauncher.launch(arrayOf("*/*")) },
        ) { showColor = false }
    }
    if (showQueue) QueueSheet(vm, ui) { showQueue = false }

    // Pick which playlist the song(s) go into
    addTargets?.let { targets ->
        AlertDialog(
            onDismissRequest = { addTargets = null },
            title = { Text("Add ${songsText(targets.size)} to playlist") },
            text = {
                Column {
                    TextButton(onClick = { createFor = targets; addTargets = null; showCreate = true }) {
                        Icon(Icons.Rounded.Add, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("New playlist")
                    }
                    LazyColumn(Modifier.height(if (playlists.size > 4) 240.dp else (playlists.size * 56).dp)) {
                        items(playlists, key = { it.id }) { pl ->
                            Text(
                                pl.name,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val added = vm.addSongsToPlaylist(pl.id, targets.map { it.id })
                                    toast(if (added > 0) "${songsText(added)} added to ${pl.name}" else "Already in ${pl.name}")
                                    addTargets = null
                                    selectedIds = emptySet()
                                }.padding(horizontal = 12.dp, vertical = 16.dp),
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { addTargets = null }) { Text("Cancel") } },
        )
    }
    if (showCreate) {
        NameDialog(
            title = "New playlist",
            initial = "",
            confirm = "Create",
            onConfirm = { name ->
                vm.createPlaylist(name, createFor.map { it.id })
                showCreate = false
                createFor = emptyList()
                selectedIds = emptySet()
            },
            onDismiss = { showCreate = false; createFor = emptyList() },
        )
    }
    if (renaming && detailPlaylist != null) {
        NameDialog(
            title = "Rename playlist",
            initial = detailPlaylist.name,
            confirm = "Save",
            onConfirm = { name -> vm.renamePlaylist(detailPlaylist.id, name); renaming = false },
            onDismiss = { renaming = false },
        )
    }
    if (confirmDelete && detailPlaylist != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete playlist?") },
            text = { Text("\"${detailPlaylist.name}\" will be deleted. Your songs stay on the phone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deletePlaylist(detailPlaylist.id)
                    confirmDelete = false
                    detail = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun NameDialog(title: String, initial: String, confirm: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(60) },
                singleLine = true,
                placeholder = { Text("Playlist name") },
            )
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onConfirm(name) }) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ------------------------------------------------------------------ home

@Composable
private fun HomeTab(
    songs: List<Song>,
    lib: LibraryState,
    currentId: Long?,
    actions: SongActions,
    byId: Map<Long, Song>,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
    onOpen: (Detail) -> Unit,
    onPlay: (List<Song>, Int) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val totalPlays = lib.plays.values.sum()
    val recent = remember(lib.recent, byId) { lib.recent.mapNotNull { byId[it] }.take(5) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column(Modifier.padding(horizontal = 4.dp)) {
                Text(greeting(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("${songs.size} songs  •  $totalPlays plays", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
        }
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(cs.surfaceContainerHighest, cs.surfaceContainer)))
                    .padding(20.dp),
            ) {
                Column {
                    Text("Your music", style = MaterialTheme.typography.titleLarge)
                    Text("Play everything, or shuffle it.", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = onPlayAll, enabled = songs.isNotEmpty()) {
                            Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Play all")
                        }
                        FilledTonalButton(onClick = onShuffle, enabled = songs.isNotEmpty()) {
                            Icon(Icons.Rounded.Shuffle, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Shuffle")
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmartTile(Icons.Rounded.Favorite, "Favourites", lib.favorites.count { it in byId }, Modifier.weight(1f)) {
                    onOpen(Detail("Favourites", emptyList(), smart = "fav"))
                }
                SmartTile(Icons.Rounded.Star, "Most played", lib.plays.count { (id, n) -> n > 0 && id in byId }.coerceAtMost(50), Modifier.weight(1f)) {
                    onOpen(Detail("Most played", emptyList(), smart = "top"))
                }
                SmartTile(Icons.Rounded.History, "Recent", lib.recent.count { it in byId }, Modifier.weight(1f)) {
                    onOpen(Detail("Recently played", emptyList(), smart = "recent"))
                }
            }
        }
        if (recent.isNotEmpty()) {
            item { Text("Recently played", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 4.dp)) }
            itemsIndexed(recent, key = { _, s -> "r${s.id}" }) { i, song ->
                SongRow(
                    song = song,
                    current = song.id == currentId,
                    selecting = false,
                    selected = false,
                    favorite = song.id in lib.favorites,
                    actions = actions,
                    onClick = { onPlay(recent, i) },
                    onLongClick = {},
                )
            }
        } else if (songs.isNotEmpty()) {
            item {
                Text(
                    "Songs you play will show up here.",
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun SmartTile(icon: ImageVector, label: String, count: Int, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainer).clickable(onClick = onClick).padding(14.dp),
    ) {
        Icon(icon, null, Modifier.size(24.dp))
        Spacer(Modifier.height(10.dp))
        Text(label, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("$count", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
    }
}

// ------------------------------------------------------------------ covers and rows

@Composable
private fun CoverBox(song: Song, corner: Dp, modifier: Modifier, iconSize: Dp) {
    Box(
        modifier.clip(RoundedCornerShape(corner)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.MusicNote, null, Modifier.size(iconSize), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        AsyncImage(model = song.artUri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
    }
}

@Composable
private fun Cover(song: Song, size: Dp, corner: Dp = 12.dp) = CoverBox(song, corner, Modifier.size(size), size / 2)

@Composable
private fun SongList(
    list: List<Song>,
    currentId: Long?,
    selected: Set<Long>,
    favorites: Set<Long>,
    showShuffle: Boolean,
    actions: SongActions,
    emptyText: String,
    onShuffle: () -> Unit,
    onTap: (Int, Song) -> Unit,
    onToggle: (Song) -> Unit,
) {
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Text(emptyText, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(32.dp))
        }
        return
    }
    val selecting = selected.isNotEmpty()
    LazyColumn(Modifier.fillMaxSize()) {
        if (showShuffle && !selecting) {
            item {
                TextButton(onClick = onShuffle, modifier = Modifier.padding(horizontal = 8.dp)) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Shuffle ${songsText(list.size)}")
                }
            }
        }
        itemsIndexed(list, key = { _, s -> s.id }) { index, song ->
            SongRow(
                song = song,
                current = song.id == currentId,
                selecting = selecting,
                selected = song.id in selected,
                favorite = song.id in favorites,
                actions = actions,
                onClick = { onTap(index, song) },
                onLongClick = { onToggle(song) },
            )
        }
    }
}

/** Rounded row like in Aurora: the playing song is outlined and bold, selected songs get a tick. */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun SongRow(
    song: Song,
    current: Boolean,
    selecting: Boolean,
    selected: Boolean,
    favorite: Boolean = false,
    actions: SongActions,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(20.dp)
    val border = when {
        selected -> cs.onSurface
        current -> cs.onSurface.copy(alpha = 0.6f)
        else -> Color.Transparent
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp)
            .background(if (selected) cs.onSurface.copy(alpha = 0.12f) else Color.Transparent, shape)
            .border(1.5.dp, border, shape)
            .clip(shape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(start = 10.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(song, 52.dp, 14.dp)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                song.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = if (current) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                "${song.artist} • ${fmt(song.durationMs)}",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (selecting) {
            Box(
                Modifier
                    .padding(end = 12.dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (selected) cs.onSurface else Color.Transparent)
                    .border(2.dp, if (selected) cs.onSurface else cs.outline, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                if (selected) Icon(Icons.Rounded.Check, null, Modifier.size(16.dp), tint = cs.background)
            }
        } else {
            if (favorite) Icon(Icons.Rounded.Favorite, null, Modifier.size(16.dp).padding(end = 0.dp))
            if (current) Icon(Icons.Rounded.GraphicEq, null, Modifier.size(20.dp))
            var menu by remember { mutableStateOf(false) }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Play next") }, onClick = { menu = false; actions.playNext(song) })
                    DropdownMenuItem(text = { Text("Add to queue") }, onClick = { menu = false; actions.addToQueue(song) })
                    DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { menu = false; actions.addToPlaylist(song) })
                    DropdownMenuItem(
                        text = { Text(if (favorite) "Remove from favourites" else "Add to favourites") },
                        onClick = { menu = false; actions.toggleFavorite(song) },
                    )
                    actions.remove?.let { remove ->
                        DropdownMenuItem(text = { Text("Remove from this playlist") }, onClick = { menu = false; remove(song) })
                    }
                }
            }
        }
    }
}

@Composable
private fun BrowseRow(song: Song, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(start = 10.dp, top = 8.dp, bottom = 8.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(song, 52.dp, 14.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ------------------------------------------------------------------ floating dock: mini player + tabs in one card

@Composable
private fun Dock(
    vm: PlayerViewModel,
    ui: PlayerUi,
    tab: Int,
    onTab: (Int) -> Unit,
    onOpenPlayer: () -> Unit,
    onOpenQueue: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        color = cs.surfaceContainerHigh,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Column {
            val song = ui.current
            if (song != null) {
                val pos by vm.position.collectAsState()
                Column(Modifier.clickable(onClick = onOpenPlayer)) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 10.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Cover(song, 44.dp, 12.dp)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                            Text(
                                song.artist,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = onOpenQueue) { Icon(Icons.Rounded.QueueMusic, "Queue") }
                        IconButton(onClick = { vm.togglePlay() }) {
                            Icon(if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (ui.isPlaying) "Pause" else "Play")
                        }
                        IconButton(onClick = { vm.next() }) { Icon(Icons.Rounded.SkipNext, "Next") }
                    }
                    val frac = if (ui.durationMs > 0) (pos.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
                    LinearProgressIndicator(
                        progress = { frac },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(2.dp),
                        color = cs.onSurface,
                        trackColor = cs.onSurface.copy(alpha = 0.15f),
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                DockTab("Home", Icons.Rounded.Home, tab == 0, Modifier.weight(1f)) { onTab(0) }
                DockTab("Songs", Icons.Rounded.MusicNote, tab == 1, Modifier.weight(1f)) { onTab(1) }
                DockTab("Albums", Icons.Rounded.Album, tab == 2, Modifier.weight(1f)) { onTab(2) }
                DockTab("Artists", Icons.Rounded.Person, tab == 3, Modifier.weight(1f)) { onTab(3) }
                DockTab("Playlists", Icons.Rounded.QueueMusic, tab == 4, Modifier.weight(1f)) { onTab(4) }
            }
        }
    }
}

@Composable
private fun DockTab(label: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val tint = if (selected) cs.onSurface else cs.onSurfaceVariant
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .height(30.dp)
                .width(50.dp)
                .clip(RoundedCornerShape(50))
                .background(if (selected) cs.onSurface.copy(alpha = 0.16f) else Color.Transparent),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, label, Modifier.size(22.dp), tint = tint) }
        Text(label, color = tint, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

// ------------------------------------------------------------------ now playing

@Composable
private fun NowPlaying(vm: PlayerViewModel, ui: PlayerUi, favorite: Boolean, onClose: () -> Unit, onQueue: () -> Unit) {
    val song = ui.current ?: return
    val cs = MaterialTheme.colorScheme
    val pos by vm.position.collectAsState()
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val duration = ui.durationMs.coerceAtLeast(1L)
    val shown = if (dragging) dragValue else pos.toFloat().coerceIn(0f, duration.toFloat())

    Column(
        Modifier.fillMaxSize().background(cs.background).statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close", Modifier.size(32.dp)) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { vm.toggleFavorite(song.id) }) {
                Icon(if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favourite")
            }
            IconButton(onClick = onQueue) { Icon(Icons.Rounded.QueueMusic, "Queue") }
        }
        Spacer(Modifier.weight(1f))
        CoverBox(song, 32.dp, Modifier.widthIn(max = 340.dp).fillMaxWidth().aspectRatio(1f), 96.dp)
        Spacer(Modifier.height(28.dp))
        Text(
            song.title,
            style = MaterialTheme.typography.headlineSmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            song.artist,
            style = MaterialTheme.typography.bodyLarge,
            color = cs.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))
        Slider(
            value = shown,
            onValueChange = { dragging = true; dragValue = it },
            onValueChangeFinished = { vm.seekTo(dragValue.toLong()); dragging = false },
            valueRange = 0f..duration.toFloat(),
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmt(shown.toLong()), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(fmt(ui.durationMs), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.height(12.dp))
        Surface(color = cs.surfaceContainer, shape = RoundedCornerShape(36.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.toggleShuffle() }) {
                Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (ui.shuffle) cs.onSurface else cs.onSurface.copy(alpha = 0.4f))
            }
            IconButton(onClick = { vm.previous() }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(36.dp))
            }
            FilledIconButton(onClick = { vm.togglePlay() }, modifier = Modifier.size(72.dp)) {
                Icon(
                    if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (ui.isPlaying) "Pause" else "Play",
                    Modifier.size(40.dp),
                )
            }
            IconButton(onClick = { vm.next() }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(36.dp))
            }
            IconButton(onClick = { vm.cycleRepeat() }) {
                Icon(
                    if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Repeat",
                    tint = if (ui.repeat == Player.REPEAT_MODE_OFF) cs.onSurface.copy(alpha = 0.4f) else cs.onSurface,
                )
            }
        }
        }
        Spacer(Modifier.weight(1.2f))
    }
}

// ------------------------------------------------------------------ queue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QueueSheet(vm: PlayerViewModel, ui: PlayerUi, onDismiss: () -> Unit) {
    val queue by vm.queue.collectAsState()
    val cs = MaterialTheme.colorScheme
    val currentPos = queue.indexOfFirst { it.index == ui.queueIndex }.coerceAtLeast(0)
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (currentPos - 1).coerceAtLeast(0))

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = cs.surfaceContainerHigh,
    ) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.8f).navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Queue", style = MaterialTheme.typography.titleLarge)
                    Text(songsText(queue.size), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                if (queue.isNotEmpty()) {
                    TextButton(onClick = { vm.clearQueue(); onDismiss() }) { Text("Clear") }
                }
            }
            if (queue.isEmpty()) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("Nothing in the queue.\nUse \"Add to queue\" in a song's ⋮ menu.", color = cs.onSurfaceVariant, modifier = Modifier.padding(32.dp))
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), state = listState) {
                    items(queue, key = { it.index }) { entry ->
                        val current = entry.index == ui.queueIndex
                        val shape = RoundedCornerShape(20.dp)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 2.dp)
                                .border(1.5.dp, if (current) cs.onSurface.copy(alpha = 0.6f) else Color.Transparent, shape)
                                .clip(shape)
                                .clickable { vm.jumpTo(entry.index) }
                                .padding(start = 10.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Cover(entry.song, 44.dp, 12.dp)
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(
                                    entry.song.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = if (current) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    entry.song.artist,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            if (current) Icon(Icons.Rounded.GraphicEq, null, Modifier.size(20.dp))
                            IconButton(onClick = { vm.removeFromQueue(entry.index) }) { Icon(Icons.Rounded.Close, "Remove from queue") }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ the only setting: colour

private val PRESETS = listOf(
    0xFF101820L, 0xFF000000L, 0xFF1E1E1EL, 0xFF2B1B4AL, 0xFF12301FL, 0xFF4A1426L,
    0xFF0F3B5AL, 0xFFF5EFE0L, 0xFFFFFFFFL, 0xFFFFD6E0L, 0xFFD4F1E4L, 0xFFD6E8FFL,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsSheet(colorInt: Int, onColor: (Int) -> Unit, onBackup: () -> Unit, onRestore: () -> Unit, onDismiss: () -> Unit) {
    val start = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(colorInt, it) } }
    var h by remember { mutableFloatStateOf(start[0]) }
    var s by remember { mutableFloatStateOf(start[1]) }
    var v by remember { mutableFloatStateOf(start[2]) }
    fun push() = onColor(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
    fun setFrom(argb: Int) {
        val t = FloatArray(3)
        android.graphics.Color.colorToHSV(argb, t)
        h = t[0]; s = t[1]; v = t[2]
        onColor(argb)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 24.dp, vertical = 8.dp)) {
            Text("App colour", style = MaterialTheme.typography.titleLarge)
            Text(
                "The background and every surface use this colour.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            PRESETS.chunked(6).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { c ->
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .clickable { setFrom(Color(c).toArgb()) },
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Hue", style = MaterialTheme.typography.labelLarge)
            Slider(value = h, onValueChange = { h = it; push() }, valueRange = 0f..360f)
            Text("Saturation", style = MaterialTheme.typography.labelLarge)
            Slider(value = s, onValueChange = { s = it; push() }, valueRange = 0f..1f)
            Text("Brightness", style = MaterialTheme.typography.labelLarge)
            Slider(value = v, onValueChange = { v = it; push() }, valueRange = 0f..1f)
            TextButton(onClick = { setFrom(DEFAULT_COLOR) }) { Text("Reset to default") }
            Spacer(Modifier.height(12.dp))
            Text("Backup", style = MaterialTheme.typography.titleLarge)
            Text(
                "Saves your playlists, favourites and colour to a file you keep. Restore it on this phone or a new one. Backups from the full Aurora app work too.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(onClick = onBackup) {
                    Icon(Icons.Rounded.Save, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Back up")
                }
                FilledTonalButton(onClick = onRestore) {
                    Icon(Icons.Rounded.Restore, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Restore")
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

package com.aurora.lite

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** One song in the play queue, with its position in the player's list. */
data class QueueEntry(val index: Int, val song: Song)

data class PlayerUi(
    val current: Song? = null,
    val isPlaying: Boolean = false,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val durationMs: Long = 0L,
    val queueIndex: Int = -1,
)

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()

    private val _queue = MutableStateFlow<List<QueueEntry>>(emptyList())
    val queue: StateFlow<List<QueueEntry>> = _queue.asStateFlow()

    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position.asStateFlow()

    private val store = PlaylistStore(app)
    private val _playlists = MutableStateFlow(store.load())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    private fun updatePlaylists(change: (List<Playlist>) -> List<Playlist>) {
        val next = change(_playlists.value)
        _playlists.value = next
        store.save(next)
    }

    fun createPlaylist(name: String, songIds: List<Long> = emptyList()) {
        val n = name.trim()
        if (n.isEmpty()) return
        updatePlaylists { it + Playlist(System.currentTimeMillis(), n.take(60), songIds) }
    }

    fun renamePlaylist(id: Long, name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(name = n.take(60)) else it } }
    }

    fun deletePlaylist(id: Long) = updatePlaylists { list -> list.filter { it.id != id } }

    /** Returns false when the song was already in the playlist. */
    fun addToPlaylist(id: Long, songId: Long): Boolean {
        val target = _playlists.value.firstOrNull { it.id == id } ?: return false
        if (songId in target.songIds) return false
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(songIds = it.songIds + songId) else it } }
        return true
    }

    /** Adds several songs, skipping ones already there. Returns how many were added. */
    fun addSongsToPlaylist(id: Long, songIds: List<Long>): Int {
        val target = _playlists.value.firstOrNull { it.id == id } ?: return 0
        val fresh = songIds.distinct().filter { it !in target.songIds }
        if (fresh.isEmpty()) return 0
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(songIds = it.songIds + fresh) else it } }
        return fresh.size
    }

    fun removeSongsFromPlaylist(id: Long, songIds: Set<Long>) =
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(songIds = it.songIds.filter { s -> s !in songIds }) else it } }

    fun removeFromPlaylist(id: Long, songId: Long) =
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(songIds = it.songIds - songId) else it } }

    private val visibleFlow = MutableStateFlow(true)
    /** False while the app is off screen, so the progress is checked less often. */
    var uiVisible: Boolean
        get() = visibleFlow.value
        set(value) { visibleFlow.value = value }

    private var controller: MediaController? = null
    private var byId: Map<Long, Song> = emptyMap()
    private var lastLoad = 0L
    private var loading = false

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync()
            if (events.containsAny(Player.EVENT_TIMELINE_CHANGED, Player.EVENT_MEDIA_ITEM_TRANSITION)) syncQueue()
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            runCatching {
                val c = future.get()
                controller = c
                c.addListener(listener)
                sync()
                syncQueue()
            }
        }, ContextCompat.getMainExecutor(app))

        // The progress is followed only while music plays. When paused nothing runs, so the CPU can sleep.
        viewModelScope.launch {
            _ui.map { it.isPlaying }.distinctUntilChanged().collectLatest { playing ->
                if (!playing) return@collectLatest
                while (true) {
                    val c = controller
                    if (c != null && visibleFlow.value) _position.value = c.currentPosition
                    // In the background check rarely, but wake at once when the app comes back on screen
                    if (visibleFlow.value) delay(500) else withTimeoutOrNull(10_000L) { visibleFlow.first { it } }
                }
            }
        }
    }

    /** Reads the music on the phone. Skipped when it was done less than half a minute ago, unless [force]. */
    fun loadSongs(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (loading || (!force && now - lastLoad < 30_000L)) return
        loading = true
        viewModelScope.launch {
            try {
                val list = MusicRepository.load(getApplication())
                byId = list.associateBy { it.id }
                _songs.value = list
                lastLoad = System.currentTimeMillis()
                sync()
                syncQueue()
            } finally {
                loading = false
            }
        }
    }

    private fun sync() {
        val c = controller ?: return
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        _ui.value = PlayerUi(
            current = id?.let { byId[it] },
            isPlaying = c.isPlaying,
            shuffle = c.shuffleModeEnabled,
            repeat = c.repeatMode,
            durationMs = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L,
            queueIndex = c.currentMediaItemIndex,
        )
        _position.value = c.currentPosition
    }

    private fun syncQueue() {
        val c = controller ?: return
        val out = ArrayList<QueueEntry>(c.mediaItemCount)
        for (i in 0 until c.mediaItemCount) {
            val song = c.getMediaItemAt(i).mediaId.toLongOrNull()?.let { byId[it] } ?: continue
            out += QueueEntry(i, song)
        }
        _queue.value = out
    }

    // ---- queue

    fun jumpTo(index: Int) {
        val c = controller ?: return
        if (index !in 0 until c.mediaItemCount) return
        c.seekTo(index, 0L)
        c.play()
    }

    fun removeFromQueue(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount) c.removeMediaItem(index)
    }

    fun clearQueue() { controller?.clearMediaItems() }

    /** Songs go right after the one that is playing. Starts playing them if nothing is queued. */
    fun playNext(songs: List<Song>) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        if (c.mediaItemCount == 0) { play(songs, 0); return }
        c.addMediaItems(c.currentMediaItemIndex + 1, songs.map { it.toMediaItem() })
    }

    /** Songs go to the end of the queue. Starts playing them if nothing is queued. */
    fun addToQueue(songs: List<Song>) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        if (c.mediaItemCount == 0) { play(songs, 0); return }
        c.addMediaItems(songs.map { it.toMediaItem() })
    }

    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        if (index !in list.indices) return
        c.shuffleModeEnabled = false
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun playShuffled(list: List<Song>) {
        val c = controller ?: return
        if (list.isEmpty()) return
        val shuffled = list.shuffled()
        c.shuffleModeEnabled = false
        c.setMediaItems(shuffled.map { it.toMediaItem() }, 0, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNext() }

    fun previous() {
        val c = controller ?: return
        // Like most players: a second tap within the first seconds goes to the previous song
        if (c.currentPosition > 3000) c.seekTo(0) else c.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        _position.value = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}

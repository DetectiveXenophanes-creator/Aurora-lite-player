# Aurora Lite

A basic music player: Songs (with search), Albums, Artists, Playlists (create, rename, delete, add / remove songs), a full-screen player, notification / lock-screen controls and background playback.
One setting only: the app colour (palette button, top right). Background and all surfaces use it; text switches between light and dark automatically.
The mini player and the tab bar are one joined dock. No glow, no themes, no widgets, no radial dock, no mascot, no translations.

Package: com.aurora.lite (installs next to Aurora). Build: `gradle assembleDebug`, or use .github/workflows/build-aurora-lite.yml.

## v1.1
- Text and icons now switch between black and white by real contrast with the chosen colour (works for mid-tones too).
- Queue: view, tap to jump, remove, clear. "Play next" / "Add to queue" in every song's menu.
- Multi-select: long-press a song, tap more, then Play / Play next / Add to queue / Add to playlist / Remove from playlist.
- Look closer to Aurora: floating rounded dock (mini player + tabs in one card), rounded song rows, outlined playing song. Static background, no animations, no glow.

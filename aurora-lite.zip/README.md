# Aurora Lite

A basic music player: Songs (with search), Albums, Artists, Playlists (create, rename, delete, add / remove songs), a full-screen player, notification / lock-screen controls and background playback.
One setting only: the app colour (palette button, top right). Background and all surfaces use it; text switches between light and dark automatically.
The mini player and the tab bar are one joined dock. No glow, no themes, no widgets, no radial dock, no mascot, no translations.

Package: com.aurora.lite (installs next to Aurora). Build: `gradle assembleDebug`, or use .github/workflows/build-aurora-lite.yml.

package com.aurora.lite

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Playlist(val id: Long, val name: String, val songIds: List<Long>)

/** Playlists are kept in the app's private storage as a small JSON text. */
class PlaylistStore(context: Context) {
    private val sp = context.getSharedPreferences("lite_playlists", Context.MODE_PRIVATE)

    fun load(): List<Playlist> = runCatching {
        val arr = JSONArray(sp.getString("data", "[]") ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ids = o.getJSONArray("songs")
            Playlist(o.getLong("id"), o.getString("name"), (0 until ids.length()).map { ids.getLong(it) })
        }
    }.getOrDefault(emptyList())

    fun save(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("songs", JSONArray(p.songIds))
            )
        }
        sp.edit().putString("data", arr.toString()).apply()
    }
}

/** Favourites, how often songs were played and what was played lately (powers the Home screen). */
data class LibraryState(
    val favorites: Set<Long> = emptySet(),
    val plays: Map<Long, Int> = emptyMap(),
    val recent: List<Long> = emptyList(),
)

class LibraryStore(context: Context) {
    private val sp = context.getSharedPreferences("lite_library", Context.MODE_PRIVATE)

    fun load(): LibraryState = runCatching {
        val fav = JSONArray(sp.getString("fav", "[]") ?: "[]")
        val rec = JSONArray(sp.getString("recent", "[]") ?: "[]")
        val pl = JSONObject(sp.getString("plays", "{}") ?: "{}")
        LibraryState(
            favorites = (0 until fav.length()).map { fav.getLong(it) }.toSet(),
            plays = pl.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to pl.getInt(k) } }.toMap(),
            recent = (0 until rec.length()).map { rec.getLong(it) },
        )
    }.getOrDefault(LibraryState())

    fun save(s: LibraryState) {
        val pl = JSONObject()
        s.plays.forEach { (id, n) -> pl.put(id.toString(), n) }
        sp.edit()
            .putString("fav", JSONArray(s.favorites.toList()).toString())
            .putString("recent", JSONArray(s.recent).toString())
            .putString("plays", pl.toString())
            .apply()
    }
}

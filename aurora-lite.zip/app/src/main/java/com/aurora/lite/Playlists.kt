package com.aurora.lite

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Playlist(val id: Long, val name: String, val songIds: List<Long>)

/** Playlists are kept in the app's private storage as a small JSON text. */
class PlaylistStore(context: Context) {
    private val sp = context.getSharedPreferences("lite_playlists", Context.MODE_PRIVATE)

    fun load(): List<Playlist> = runCatching {
        val arr = JSONArray(sp.getString("data", "[]") ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ids = o.getJSONArray("songs")
            Playlist(o.getLong("id"), o.getString("name"), (0 until ids.length()).map { ids.getLong(it) })
        }
    }.getOrDefault(emptyList())

    fun save(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("songs", JSONArray(p.songIds))
            )
        }
        sp.edit().putString("data", arr.toString()).apply()
    }
}

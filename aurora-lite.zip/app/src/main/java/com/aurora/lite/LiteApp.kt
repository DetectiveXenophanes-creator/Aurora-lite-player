package com.aurora.lite

import android.Manifest
import android.widget.Toast
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.Player
import coil.compose.AsyncImage

private data class Detail(val title: String, val songs: List<Song>, val playlistId: Long? = null)

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun LiteApp(vm: PlayerViewModel, colorInt: Int, onColor: (Int) -> Unit) {
    val context = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, audioPermission()) == android.content.pm.PackageManager.PERMISSION_GRANTED)
    }
    val request = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[audioPermission()] == true) {
            granted = true
            vm.loadSongs(force = true)
        }
    }

    // Know when the app is on screen (fewer wake-ups in the background) and refresh the music list when it returns
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, granted) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) {
                vm.uiVisible = true
                if (granted) vm.loadSongs()
            } else if (event == Lifecycle.Event.ON_STOP) {
                vm.uiVisible = false
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (!granted) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(32.dp), Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Icon(Icons.Rounded.MusicNote, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onBackground)
                Text("Aurora Lite", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground)
                Text(
                    "Allow access to your music so Aurora Lite can play it.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = {
                    val perms = if (Build.VERSION.SDK_INT >= 33) {
                        arrayOf(audioPermission(), Manifest.permission.POST_NOTIFICATIONS)
                    } else arrayOf(audioPermission())
                    request.launch(perms)
                }) { Text("Allow") }
            }
        }
        return
    }
    LaunchedEffect(Unit) { vm.loadSongs() }
    LiteMain(vm, colorInt, onColor)
}

@Composable
private fun LiteMain(vm: PlayerViewModel, colorInt: Int, onColor: (Int) -> Unit) {
    val songs by vm.songs.collectAsState()
    val ui by vm.ui.collectAsState()
    var tab by rememberSaveable { mutableStateOf(0) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var showColor by remember { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    val playlists by vm.playlists.collectAsState()
    val context = LocalContext.current
    var addTarget by remember { mutableStateOf<Song?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var createFor by remember { mutableStateOf<Song?>(null) }
    var renaming by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val byId = remember(songs) { songs.associateBy { it.id } }
    val detailPlaylist = detail?.playlistId?.let { id -> playlists.firstOrNull { it.id == id } }

    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = !showPlayer && detail != null) { detail = null }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (detail != null) {
                    IconButton(onClick = { detail = null }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
                }
                Text(
                    detailPlaylist?.name ?: detail?.title ?: "Aurora Lite",
                    style = MaterialTheme.typography.headlineSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (detailPlaylist != null) {
                    IconButton(onClick = { renaming = true }) { Icon(Icons.Rounded.Edit, "Rename playlist") }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, "Delete playlist") }
                } else {
                    IconButton(onClick = { showColor = true }) { Icon(Icons.Rounded.Palette, "Colour") }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                val d = detail
                when {
                    d != null -> {
                        val list = if (d.playlistId != null) {
                            detailPlaylist?.songIds?.mapNotNull { byId[it] } ?: emptyList()
                        } else d.songs
                        SongList(
                            list, vm, showShuffle = true,
                            onAddToPlaylist = { addTarget = it },
                            onRemove = detailPlaylist?.let { pl -> { song: Song -> vm.removeFromPlaylist(pl.id, song.id) } },
                            emptyText = if (d.playlistId != null) "This playlist is empty.\nUse the ⋮ menu on any song to add it." else "No songs found",
                        )
                    }
                    tab == 0 -> {
                        Column(Modifier.fillMaxSize()) {
                            OutlinedTextField(
                                value = query,
                                onValueChange = { query = it },
                                singleLine = true,
                                placeholder = { Text("Search songs") },
                                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                                shape = RoundedCornerShape(28.dp),
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                            )
                            val q = query.trim()
                            val shown = remember(songs, q) {
                                if (q.isEmpty()) songs else songs.filter {
                                    it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
                                }
                            }
                            SongList(shown, vm, showShuffle = q.isEmpty(), onAddToPlaylist = { addTarget = it })
                        }
                    }
                    tab == 1 -> {
                        val albums = remember(songs) {
                            songs.groupBy { it.albumId }.values.sortedBy { it.first().album.lowercase() }
                        }
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(albums, key = { it.first().albumId }) { list ->
                                val first = list.first()
                                val artist = if (list.map { it.artist }.distinct().size > 1) "Various artists" else first.artist
                                BrowseRow(first, first.album, "$artist · ${list.size} songs", Icons.Rounded.Album) {
                                    detail = Detail(first.album, list)
                                }
                            }
                        }
                    }
                    tab == 2 -> {
                        val artists = remember(songs) {
                            songs.groupBy { it.artist }.entries.sortedBy { it.key.lowercase() }
                        }
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(artists, key = { it.key }) { e ->
                                BrowseRow(e.value.first(), e.key, "${e.value.size} songs", Icons.Rounded.Person) {
                                    detail = Detail(e.key, e.value)
                                }
                            }
                        }
                    }
                    else -> {
                        LazyColumn(Modifier.fillMaxSize()) {
                            item {
                                TextButton(
                                    onClick = { createFor = null; showCreate = true },
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                ) {
                                    Icon(Icons.Rounded.Add, null, Modifier.size(20.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("New playlist")
                                }
                            }
                            if (playlists.isEmpty()) {
                                item {
                                    Text(
                                        "No playlists yet. Create one, then add songs with the ⋮ menu on any song.",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                                    )
                                }
                            }
                            items(playlists, key = { it.id }) { pl ->
                                val count = pl.songIds.count { it in byId }
                                Row(
                                    Modifier.fillMaxWidth()
                                        .clickable { detail = Detail(pl.name, emptyList(), pl.id) }
                                        .padding(horizontal = 16.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Box(
                                        Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center,
                                    ) { Icon(Icons.Rounded.QueueMusic, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                                        Text(pl.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                        Text(
                                            if (count == 1) "1 song" else "$count songs",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Dock(vm, ui, tab, onTab = { tab = it; detail = null }, onOpenPlayer = { showPlayer = true })
        }

        AnimatedVisibility(
            visible = showPlayer && ui.current != null,
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
        ) {
            NowPlaying(vm, ui, onClose = { showPlayer = false })
        }
    }

    if (showColor) ColorSheet(colorInt, onColor) { showColor = false }

    // Pick which playlist a song goes into
    addTarget?.let { song ->
        AlertDialog(
            onDismissRequest = { addTarget = null },
            title = { Text("Add to playlist") },
            text = {
                Column {
                    TextButton(onClick = { createFor = song; addTarget = null; showCreate = true }) {
                        Icon(Icons.Rounded.Add, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("New playlist")
                    }
                    LazyColumn(Modifier.height(if (playlists.size > 4) 240.dp else (playlists.size * 56).dp)) {
                        items(playlists, key = { it.id }) { pl ->
                            Text(
                                pl.name,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val added = vm.addToPlaylist(pl.id, song.id)
                                    Toast.makeText(
                                        context,
                                        if (added) "Added to ${pl.name}" else "Already in ${pl.name}",
                                        Toast.LENGTH_SHORT,
                                    ).show()
                                    addTarget = null
                                }.padding(horizontal = 12.dp, vertical = 16.dp),
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { addTarget = null }) { Text("Cancel") } },
        )
    }
    if (showCreate) {
        NameDialog(
            title = "New playlist",
            initial = "",
            confirm = "Create",
            onConfirm = { name ->
                vm.createPlaylist(name, listOfNotNull(createFor?.id))
                showCreate = false
                createFor = null
            },
            onDismiss = { showCreate = false; createFor = null },
        )
    }
    if (renaming && detailPlaylist != null) {
        NameDialog(
            title = "Rename playlist",
            initial = detailPlaylist.name,
            confirm = "Save",
            onConfirm = { name -> vm.renamePlaylist(detailPlaylist.id, name); renaming = false },
            onDismiss = { renaming = false },
        )
    }
    if (confirmDelete && detailPlaylist != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete playlist?") },
            text = { Text("\"${detailPlaylist.name}\" will be deleted. Your songs stay on the phone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deletePlaylist(detailPlaylist.id)
                    confirmDelete = false
                    detail = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun NameDialog(title: String, initial: String, confirm: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(60) },
                singleLine = true,
                placeholder = { Text("Playlist name") },
            )
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onConfirm(name) }) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ------------------------------------------------------------------ lists

@Composable
private fun Cover(song: Song, size: androidx.compose.ui.unit.Dp, corner: androidx.compose.ui.unit.Dp = 10.dp, modifier: Modifier = Modifier) {
    Box(
        modifier.size(size).clip(RoundedCornerShape(corner)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.MusicNote, null, Modifier.size(size / 2), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        AsyncImage(model = song.artUri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
    }
}

@Composable
private fun SongList(
    list: List<Song>,
    vm: PlayerViewModel,
    showShuffle: Boolean,
    onAddToPlaylist: (Song) -> Unit,
    onRemove: ((Song) -> Unit)? = null,
    emptyText: String = "No songs found",
) {
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            Text(emptyText, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(32.dp))
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        if (showShuffle) {
            item {
                TextButton(onClick = { vm.playShuffled(list) }, modifier = Modifier.padding(horizontal = 8.dp)) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Shuffle ${list.size} songs")
                }
            }
        }
        itemsIndexed(list, key = { _, s -> s.id }) { index, song ->
            Row(
                Modifier.fillMaxWidth().clickable { vm.play(list, index) }.padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Cover(song, 48.dp)
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        song.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(fmt(song.durationMs), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                var menu by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { menu = false; onAddToPlaylist(song) })
                        if (onRemove != null) {
                            DropdownMenuItem(text = { Text("Remove from this playlist") }, onClick = { menu = false; onRemove(song) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BrowseRow(song: Song, title: String, subtitle: String, @Suppress("UNUSED_PARAMETER") icon: ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(song, 56.dp, 12.dp)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ------------------------------------------------------------------ joined dock: mini player + tabs in one bar

@Composable
private fun Dock(vm: PlayerViewModel, ui: PlayerUi, tab: Int, onTab: (Int) -> Unit, onOpenPlayer: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        color = cs.surfaceContainerHigh,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        tonalElevation = 0.dp,
    ) {
        Column(Modifier.navigationBarsPadding()) {
            val song = ui.current
            if (song != null) {
                val pos by vm.position.collectAsState()
                Column(Modifier.clickable(onClick = onOpenPlayer)) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Cover(song, 44.dp)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(song.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                song.artist,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = { vm.togglePlay() }) {
                            Icon(if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (ui.isPlaying) "Pause" else "Play")
                        }
                        IconButton(onClick = { vm.next() }) { Icon(Icons.Rounded.SkipNext, "Next") }
                    }
                    val frac = if (ui.durationMs > 0) (pos.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
                    LinearProgressIndicator(
                        progress = { frac },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(2.dp),
                        color = cs.onSurface,
                        trackColor = cs.onSurface.copy(alpha = 0.15f),
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                DockTab("Songs", Icons.Rounded.MusicNote, tab == 0) { onTab(0) }
                DockTab("Albums", Icons.Rounded.Album, tab == 1) { onTab(1) }
                DockTab("Artists", Icons.Rounded.Person, tab == 2) { onTab(2) }
                DockTab("Playlists", Icons.Rounded.QueueMusic, tab == 3) { onTab(3) }
            }
        }
    }
}

@Composable
private fun DockTab(label: String, icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) cs.onSurface.copy(alpha = 0.14f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, Modifier.size(24.dp), tint = if (selected) cs.onSurface else cs.onSurfaceVariant)
        Text(label, style = MaterialTheme.typography.labelSmall, color = if (selected) cs.onSurface else cs.onSurfaceVariant)
    }
}

// ------------------------------------------------------------------ now playing

@Composable
private fun NowPlaying(vm: PlayerViewModel, ui: PlayerUi, onClose: () -> Unit) {
    val song = ui.current ?: return
    val cs = MaterialTheme.colorScheme
    val pos by vm.position.collectAsState()
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val duration = ui.durationMs.coerceAtLeast(1L)
    val shown = if (dragging) dragValue else pos.toFloat().coerceIn(0f, duration.toFloat())

    Column(
        Modifier.fillMaxSize().background(cs.background).statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close", Modifier.size(32.dp)) }
        }
        Spacer(Modifier.weight(1f))
        Cover(song, 300.dp, 24.dp, Modifier.fillMaxWidth().height(300.dp).let { it })
        Spacer(Modifier.height(28.dp))
        Text(
            song.title,
            style = MaterialTheme.typography.headlineSmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            song.artist,
            style = MaterialTheme.typography.bodyLarge,
            color = cs.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))
        Slider(
            value = shown,
            onValueChange = { dragging = true; dragValue = it },
            onValueChangeFinished = { vm.seekTo(dragValue.toLong()); dragging = false },
            valueRange = 0f..duration.toFloat(),
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmt(shown.toLong()), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(fmt(ui.durationMs), style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.toggleShuffle() }) {
                Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (ui.shuffle) cs.onSurface else cs.onSurface.copy(alpha = 0.4f))
            }
            IconButton(onClick = { vm.previous() }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(36.dp))
            }
            FilledIconButton(onClick = { vm.togglePlay() }, modifier = Modifier.size(72.dp)) {
                Icon(
                    if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (ui.isPlaying) "Pause" else "Play",
                    Modifier.size(40.dp),
                )
            }
            IconButton(onClick = { vm.next() }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(36.dp))
            }
            IconButton(onClick = { vm.cycleRepeat() }) {
                Icon(
                    if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Repeat",
                    tint = if (ui.repeat == Player.REPEAT_MODE_OFF) cs.onSurface.copy(alpha = 0.4f) else cs.onSurface,
                )
            }
        }
        Spacer(Modifier.weight(1.2f))
    }
}

// ------------------------------------------------------------------ the only setting: colour

private val PRESETS = listOf(
    0xFF101820L, 0xFF000000L, 0xFF1E1E1EL, 0xFF2B1B4AL, 0xFF12301FL, 0xFF4A1426L,
    0xFF0F3B5AL, 0xFFF5EFE0L, 0xFFFFFFFFL, 0xFFFFD6E0L, 0xFFD4F1E4L, 0xFFD6E8FFL,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ColorSheet(colorInt: Int, onColor: (Int) -> Unit, onDismiss: () -> Unit) {
    val start = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(colorInt, it) } }
    var h by remember { mutableFloatStateOf(start[0]) }
    var s by remember { mutableFloatStateOf(start[1]) }
    var v by remember { mutableFloatStateOf(start[2]) }
    fun push() = onColor(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
    fun setFrom(argb: Int) {
        val t = FloatArray(3)
        android.graphics.Color.colorToHSV(argb, t)
        h = t[0]; s = t[1]; v = t[2]
        onColor(argb)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 8.dp)) {
            Text("App colour", style = MaterialTheme.typography.titleLarge)
            Text(
                "The background and every surface use this colour.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            PRESETS.chunked(6).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { c ->
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .clickable { setFrom(Color(c).toArgb()) },
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Hue", style = MaterialTheme.typography.labelLarge)
            Slider(value = h, onValueChange = { h = it; push() }, valueRange = 0f..360f)
            Text("Saturation", style = MaterialTheme.typography.labelLarge)
            Slider(value = s, onValueChange = { s = it; push() }, valueRange = 0f..1f)
            Text("Brightness", style = MaterialTheme.typography.labelLarge)
            Slider(value = v, onValueChange = { v = it; push() }, valueRange = 0f..1f)
            TextButton(onClick = { setFrom(DEFAULT_COLOR) }) { Text("Reset to default") }
            Spacer(Modifier.height(12.dp))
        }
    }
}

package com.aurora.lite

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** What a restore did, and the colour to apply if the backup carried one. */
data class RestoreResult(val message: String, val color: Int? = null)

/** One song in the play queue, with its position in the player's list. */
data class QueueEntry(val index: Int, val song: Song)

data class PlayerUi(
    val current: Song? = null,
    val isPlaying: Boolean = false,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val durationMs: Long = 0L,
    val queueIndex: Int = -1,
)

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()

    private val _queue = MutableStateFlow<List<QueueEntry>>(emptyList())
    val queue: StateFlow<List<QueueEntry>> = _queue.asStateFlow()

    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position.asStateFlow()

    private val libStore = LibraryStore(app)
    private val _library = MutableStateFlow(libStore.load())
    val library: StateFlow<LibraryState> = _library.asStateFlow()
    private var countedFor: Long? = null

    private fun updateLibrary(change: (LibraryState) -> LibraryState) {
        val next = change(_library.value)
        _library.value = next
        libStore.save(next)
    }

    fun toggleFavorite(id: Long) = updateLibrary {
        it.copy(favorites = if (id in it.favorites) it.favorites - id else it.favorites + id)
    }

    fun addFavorites(ids: List<Long>) = updateLibrary { it.copy(favorites = it.favorites + ids) }

    private fun recordPlay(id: Long) = updateLibrary {
        it.copy(
            plays = it.plays + (id to ((it.plays[id] ?: 0) + 1)),
            recent = (listOf(id) + it.recent.filter { r -> r != id }).take(30),
        )
    }

    private val store = PlaylistStore(app)
    private val _playlists = MutableStateFlow(store.load())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()

    private fun updatePlaylists(change: (List<Playlist>) -> List<Playlist>) {
        val next = change(_playlists.value)
        _playlists.value = next
        store.save(next)
    }

    fun createPlaylist(name: String, songIds: List<Long> = emptyList()) {
        val n = name.trim()
        if (n.isEmpty()) return
        updatePlaylists { it + Playlist(System.currentTimeMillis(), n.take(60), songIds) }
    }

    fun renamePlaylist(id: Long, name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(name = n.take(60)) else it } }
    }

    fun deletePlaylist(id: Long) = updatePlaylists { list -> list.filter { it.id != id } }

    /** Returns false when the song was already in the playlist. */
    fun addToPlaylist(id: Long, songId: Long): Boolean {
        val target = _playlists.value.firstOrNull { it.id == id } ?: return false
        if (songId in target.songIds) return false
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(songIds = it.songIds + songId) else it } }
        return true
    }

    /** Adds several songs, skipping ones already there. Returns how many were added. */
    fun addSongsToPlaylist(id: Long, songIds: List<Long>): Int {
        val target = _playlists.value.firstOrNull { it.id == id } ?: return 0
        val fresh = songIds.distinct().filter { it !in target.songIds }
        if (fresh.isEmpty()) return 0
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(songIds = it.songIds + fresh) else it } }
        return fresh.size
    }

    fun removeSongsFromPlaylist(id: Long, songIds: Set<Long>) =
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(songIds = it.songIds.filter { s -> s !in songIds }) else it } }

    fun removeFromPlaylist(id: Long, songId: Long) =
        updatePlaylists { list -> list.map { if (it.id == id) it.copy(songIds = it.songIds - songId) else it } }

    private val visibleFlow = MutableStateFlow(true)
    /** False while the app is off screen, so the progress is checked less often. */
    var uiVisible: Boolean
        get() = visibleFlow.value
        set(value) { visibleFlow.value = value }

    private var controller: MediaController? = null
    private var byId: Map<Long, Song> = emptyMap()
    private var lastLoad = 0L
    private var loading = false

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) countedFor = null
            sync()
            if (events.containsAny(Player.EVENT_TIMELINE_CHANGED, Player.EVENT_MEDIA_ITEM_TRANSITION)) syncQueue()
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            runCatching {
                val c = future.get()
                controller = c
                c.addListener(listener)
                sync()
                syncQueue()
            }
        }, ContextCompat.getMainExecutor(app))

        // The progress is followed only while music plays. When paused nothing runs, so the CPU can sleep.
        viewModelScope.launch {
            _ui.map { it.isPlaying }.distinctUntilChanged().collectLatest { playing ->
                if (!playing) return@collectLatest
                while (true) {
                    val c = controller
                    if (c != null && visibleFlow.value) _position.value = c.currentPosition
                    // A song counts as played once 20 seconds of it have been heard
                    if (c != null && c.isPlaying) {
                        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
                        if (id != null && id != countedFor && c.currentPosition >= 20_000L) {
                            countedFor = id
                            recordPlay(id)
                        }
                    }
                    // In the background check rarely, but wake at once when the app comes back on screen
                    if (visibleFlow.value) delay(500) else withTimeoutOrNull(10_000L) { visibleFlow.first { it } }
                }
            }
        }
    }

    /** Reads the music on the phone. Skipped when it was done less than half a minute ago, unless [force]. */
    fun loadSongs(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (loading || (!force && now - lastLoad < 30_000L)) return
        loading = true
        viewModelScope.launch {
            try {
                val list = MusicRepository.load(getApplication())
                byId = list.associateBy { it.id }
                _songs.value = list
                lastLoad = System.currentTimeMillis()
                sync()
                syncQueue()
            } finally {
                loading = false
            }
        }
    }

    private fun sync() {
        val c = controller ?: return
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        _ui.value = PlayerUi(
            current = id?.let { byId[it] },
            isPlaying = c.isPlaying,
            shuffle = c.shuffleModeEnabled,
            repeat = c.repeatMode,
            durationMs = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L,
            queueIndex = c.currentMediaItemIndex,
        )
        _position.value = c.currentPosition
    }

    private fun syncQueue() {
        val c = controller ?: return
        val out = ArrayList<QueueEntry>(c.mediaItemCount)
        for (i in 0 until c.mediaItemCount) {
            val song = c.getMediaItemAt(i).mediaId.toLongOrNull()?.let { byId[it] } ?: continue
            out += QueueEntry(i, song)
        }
        _queue.value = out
    }

    // ---- queue

    fun jumpTo(index: Int) {
        val c = controller ?: return
        if (index !in 0 until c.mediaItemCount) return
        c.seekTo(index, 0L)
        c.play()
    }

    fun removeFromQueue(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount) c.removeMediaItem(index)
    }

    fun clearQueue() { controller?.clearMediaItems() }

    /** Songs go right after the one that is playing. Starts playing them if nothing is queued. */
    fun playNext(songs: List<Song>) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        if (c.mediaItemCount == 0) { play(songs, 0); return }
        c.addMediaItems(c.currentMediaItemIndex + 1, songs.map { it.toMediaItem() })
    }

    /** Songs go to the end of the queue. Starts playing them if nothing is queued. */
    fun addToQueue(songs: List<Song>) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        if (c.mediaItemCount == 0) { play(songs, 0); return }
        c.addMediaItems(songs.map { it.toMediaItem() })
    }

    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        if (index !in list.indices) return
        c.shuffleModeEnabled = false
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun playShuffled(list: List<Song>) {
        val c = controller ?: return
        if (list.isEmpty()) return
        val shuffled = list.shuffled()
        c.shuffleModeEnabled = false
        c.setMediaItems(shuffled.map { it.toMediaItem() }, 0, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNext() }

    fun previous() {
        val c = controller ?: return
        // Like most players: a second tap within the first seconds goes to the previous song
        if (c.currentPosition > 3000) c.seekTo(0) else c.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        _position.value = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    // ---- backup and restore

    /** Playlists (songs listed by name, not as files), favourites and the app colour, as JSON text. */
    fun createBackup(color: Int): String {
        val songs = byId
        fun ref(id: Long): JSONObject {
            val song = songs[id]
            return JSONObject().put("id", id).put("title", song?.title ?: "").put("artist", song?.artist ?: "")
                .put("dur", song?.durationMs ?: 0L)
        }
        val playlists = JSONArray()
        _playlists.value.forEach { p ->
            val arr = JSONArray()
            p.songIds.forEach { arr.put(ref(it)) }
            playlists.put(JSONObject().put("name", p.name).put("songs", arr))
        }
        val favorites = JSONArray()
        _library.value.favorites.forEach { favorites.put(ref(it)) }
        return JSONObject()
            .put("app", "AuroraLite")
            .put("version", 1)
            .put("created", System.currentTimeMillis())
            .put("color", color)
            .put("playlists", playlists)
            .put("favorites", favorites)
            .toString(2)
    }

    /** Merges a backup into this phone: playlists with the same name are combined. Also reads backups made by full Aurora. */
    fun restoreBackup(text: String): RestoreResult {
        val root = try { JSONObject(text) } catch (e: Exception) { return RestoreResult("That file is not an Aurora backup.") }
        val app = root.optString("app")
        if (app != "AuroraLite" && app != "Aurora") return RestoreResult("That file is not an Aurora backup.")

        val songs = _songs.value
        if (songs.isEmpty()) return RestoreResult("Your music has not loaded yet. Try again in a moment.")
        var matched = 0
        var missing = 0
        fun resolve(o: JSONObject): Long? {
            val id = o.optLong("id", -1L)
            val title = o.optString("title")
            val artist = o.optString("artist")
            val dur = o.optLong("dur", 0L)
            val same = byId[id]
            if (same != null && (title.isEmpty() || same.title.equals(title, true))) return same.id
            if (title.isEmpty()) return null
            return songs.firstOrNull { it.title.equals(title, true) && it.artist.equals(artist, true) && abs(it.durationMs - dur) < 3000 }?.id
                ?: songs.firstOrNull { it.title.equals(title, true) && abs(it.durationMs - dur) < 3000 }?.id
        }

        var added = 0
        val arr = root.optJSONArray("playlists")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.optString("name", "Playlist").ifBlank { "Playlist" }
                val ids = mutableListOf<Long>()
                val sa = o.optJSONArray("songs")
                if (sa != null) {
                    for (j in 0 until sa.length()) {
                        val r = resolve(sa.getJSONObject(j))
                        if (r != null) { ids += r; matched++ } else missing++
                    }
                }
                updatePlaylists { list ->
                    val existing = list.firstOrNull { it.name.equals(name, true) }
                    if (existing != null) {
                        list.map { if (it.id == existing.id) it.copy(songIds = it.songIds + ids.filter { id -> id !in it.songIds }) else it }
                    } else {
                        list + Playlist(System.currentTimeMillis() + i, name, ids.distinct())
                    }
                }
                added++
            }
        }
        val favs = mutableSetOf<Long>()
        root.optJSONArray("favorites")?.let { fa ->
            for (i in 0 until fa.length()) resolve(fa.getJSONObject(i))?.let { favs += it }
        }
        if (favs.isNotEmpty()) addFavorites(favs.toList())

        val color = if (app == "AuroraLite" && root.has("color")) root.optInt("color") else null
        return RestoreResult(
            "Restored $added playlists ($matched songs matched, $missing not found on this phone)" +
                (if (favs.isNotEmpty()) " and ${favs.size} favourites." else "."),
            color,
        )
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}

package com.aurora.lite

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val DEFAULT_COLOR: Int = 0xFF1B1B2F.toInt()

/** The one thing the user can customise: the colour of the whole app. */
class LitePrefs(context: Context) {
    private val sp = context.getSharedPreferences("lite", Context.MODE_PRIVATE)
    fun color(): Int = sp.getInt("color", DEFAULT_COLOR)
    fun setColor(c: Int) { sp.edit().putInt("color", c).apply() }
}

/** Background and every surface come from the chosen colour; text and icons switch between light and dark so they stay readable. */
@Composable
fun LiteTheme(colorInt: Int, content: @Composable () -> Unit) {
    val base = Color(colorInt)
    // Black text on bright colours, white text on dark ones. 0.179 is the exact point where black and white give equal
    // contrast, so mid-tones (red, teal, orange...) get whichever of the two is easier to read.
    val light = base.luminance() > 0.179f
    val scheme = remember(colorInt) {
        val on = if (light) Color(0xFF000000) else Color(0xFFFFFFFF)
        fun mix(a: Float) = lerp(base, on, a)
        darkColorScheme(
            primary = on,
            onPrimary = base,
            primaryContainer = mix(0.16f),
            onPrimaryContainer = on,
            secondary = on,
            onSecondary = base,
            secondaryContainer = mix(0.16f),
            onSecondaryContainer = on,
            tertiary = on,
            onTertiary = base,
            background = base,
            onBackground = on,
            surface = base,
            onSurface = on,
            surfaceVariant = mix(0.10f),
            onSurfaceVariant = on.copy(alpha = 0.78f),
            surfaceTint = on,
            outline = on.copy(alpha = 0.45f),
            outlineVariant = on.copy(alpha = 0.2f),
            surfaceContainerLowest = mix(0.02f),
            surfaceContainerLow = mix(0.04f),
            surfaceContainer = mix(0.07f),
            surfaceContainerHigh = mix(0.10f),
            surfaceContainerHighest = mix(0.14f),
        )
    }
    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let { w ->
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = light
            c.isAppearanceLightNavigationBars = light
        }
    }
    MaterialTheme(colorScheme = scheme) {
        // This is what makes every title, heading and icon use the black/white text colour. Without it Compose
        // falls back to plain black for any text that has no colour of its own.
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = scheme.background,
            contentColor = scheme.onBackground,
            content = content,
        )
    }
}

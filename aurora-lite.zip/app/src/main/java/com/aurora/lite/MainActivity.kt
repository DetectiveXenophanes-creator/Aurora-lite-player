package com.aurora.lite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = LitePrefs(this)
        setContent {
            val vm: PlayerViewModel = viewModel()
            var color by remember { mutableIntStateOf(prefs.color()) }
            LiteTheme(color) {
                LiteApp(vm = vm, colorInt = color, onColor = { color = it; prefs.setColor(it) })
            }
        }
    }
}

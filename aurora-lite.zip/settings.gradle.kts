pluginManagement {
    repositories {
        google()
        // Google's public mirror of Maven Central, tried before repo.maven.apache.org. GitHub Actions runners
        // sometimes get 403/404 answers from Maven Central's CDN (the "Could not find ... .jar" failure).
        // If the mirror lacks something, Gradle falls through to the real mavenCentral().
        maven(url = "https://maven-central.storage-download.googleapis.com/maven2/")
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        maven(url = "https://maven-central.storage-download.googleapis.com/maven2/")
        mavenCentral()
    }
}
rootProject.name = "AuroraLite"
include(":app")
